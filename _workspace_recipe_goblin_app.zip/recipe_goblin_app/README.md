# Recipe Goblin - AI-Powered Cooking Blog App

Recipe Goblin is a web application that allows users to generate cooking blog content using AI technology. Inspired by ContentGoblin.ai, this app focuses specifically on creating cooking and recipe content.

## Features

### For Users
- **Recipe Generator**: Create complete recipe listicles in seconds
- **User Registration & Login**: Create an account to save and manage recipes
- **Recipe Management**: Save, edit, and organize your recipes
- **Recipe Details**: View detailed recipe information including ingredients, instructions, and nutritional info
- **User Dashboard**: Track your recipe creation activity and manage your content

### For Administrators
- **User Management**: Add, edit, and manage user accounts
- **Dashboard**: View site statistics and user activity
- **Content Management**: Manage recipes, categories, and comments
- **Analytics**: Track user engagement and popular content

## Pages

### User-Facing Pages
- **Home Page**: Main landing page with recipe generator
- **Login Page**: User authentication
- **Registration Page**: New user signup
- **Recipe Detail Page**: Detailed view of a specific recipe
- **Dashboard**: User's personal dashboard

### Admin Pages
- **Admin Dashboard**: Overview of site statistics
- **User Management**: Manage user accounts
- **Recipe Management**: Manage recipe content

## Technical Details

### Technology Stack
- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Styling**: Custom CSS with responsive design
- **Icons**: Font Awesome
- **Charts**: Chart.js for analytics visualization
- **Storage**: LocalStorage for demo purposes (would use a backend database in production)

### File Structure
- `/css`: Stylesheet files
- `/js`: JavaScript files
- `/images`: Image assets
- `/admin`: Admin panel pages

## How to Use

### For Users
1. **Create an Account**: Register using the registration page
2. **Generate Recipes**: Use the recipe generator on the home page
3. **Save Recipes**: Save generated recipes to your collection
4. **Manage Recipes**: Access your saved recipes from the dashboard

### For Administrators
1. **Access Admin Panel**: Navigate to the `/admin` directory
2. **Manage Users**: Add, edit, or remove users from the User Management page
3. **View Analytics**: Check site statistics on the Admin Dashboard
4. **Manage Content**: Control recipe content and categories

## User Registration Control

Administrators can control user registrations through the User Management page in the admin panel:

1. **View Users**: See all registered users
2. **Add Users**: Manually add new users
3. **Edit Users**: Modify user information and roles
4. **Delete Users**: Remove user accounts
5. **Set User Status**: Mark users as active, pending, or blocked

## Development

### Local Development
1. Clone the repository
2. Open index.html in your browser
3. No build process required as this is a frontend-only application

### Extending the App
- **Backend Integration**: Connect to a real backend for data persistence
- **Authentication**: Implement proper authentication mechanisms
- **Image Upload**: Add functionality for users to upload their own images
- **Social Features**: Add sharing and commenting functionality

## Credits
- Design inspired by ContentGoblin.ai
- Images from Unsplash
- Icons from Font Awesome
- Fonts from Google Fonts

## License
This project is for demonstration purposes only.