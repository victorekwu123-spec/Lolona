# Recipe Goblin Quick Start Guide

Welcome to Recipe Goblin! This guide will help you get started with our AI-powered cooking blog generator.

## Getting Started

### 1. Create an Account

1. Click on the "Register" link in the navigation menu
2. Fill out the registration form with your:
   - Full name
   - Email address
   - Password (must be at least 8 characters)
3. Agree to the Terms of Service
4. Click "Create Account"
5. You'll be automatically logged in and redirected to the dashboard

### 2. Generate Your First Recipe

1. Navigate to the home page
2. Scroll down to the Recipe Generator section
3. Enter a recipe topic (e.g., "Healthy Smoothies", "Quick Pasta Dishes")
4. Select a recipe type (Breakfast, Lunch, Dinner, Dessert, or Snack)
5. Choose the number of items you want in your listicle (3, 5, 7, or 10)
6. Click "Generate Recipe"
7. Wait a few seconds for the AI to create your recipe content

### 3. Save and Manage Recipes

1. After generating a recipe, click the "Save Recipe" button
2. The recipe will be added to your saved recipes collection
3. View your saved recipes by scrolling down to the "Saved Recipes" section
4. Click on any recipe card to view the full recipe details

### 4. Explore Your Dashboard

1. Click on "Dashboard" in the navigation menu
2. Here you can:
   - See statistics about your recipe creation
   - View your recently created recipes
   - Access your saved recipes
   - Manage your account settings

## Key Features

### Recipe Generator

The heart of Recipe Goblin is the AI-powered recipe generator that creates:

- Recipe titles and descriptions
- List of recipe items with descriptions
- High-quality food images for each item
- Complete recipe listicles ready to share

### Recipe Details

Each recipe includes:

- Ingredients list
- Step-by-step instructions
- Nutritional information
- Cooking tips
- Recipe variations
- User reviews and ratings

### User Dashboard

Your personal dashboard provides:

- Recipe creation statistics
- Recently viewed recipes
- Saved recipe collection
- Activity tracking

## Tips for Best Results

1. **Be specific with your topics**: "Summer Salads with Berries" will give better results than just "Salads"

2. **Choose the right recipe type**: This helps the AI generate more appropriate content

3. **Experiment with different item counts**: More items give more variety, fewer items provide more focused content

4. **Save recipes you like**: Saved recipes are stored in your account for future reference

5. **Edit generated content**: You can always customize the AI-generated content to add your personal touch

## Need Help?

If you have any questions or need assistance:

1. Check our FAQ section (coming soon)
2. Contact support at support@recipegoblin.com
3. Visit our help center for detailed guides

Happy cooking with Recipe Goblin!