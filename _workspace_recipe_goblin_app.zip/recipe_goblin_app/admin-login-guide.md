# Admin Login Guide for Recipe Goblin

Since this is a demo application using LocalStorage for data persistence, we need to set up an admin account manually. Here's how to do it:

## Option 1: Register and Modify Role

1. First, register a new account through the registration page
2. Then modify the user role to "admin" in LocalStorage

## Option 2: Use Pre-configured Admin Account

For your convenience, I'll create a pre-configured admin account that you can use immediately:

- **Email**: admin@recipegoblin.com
- **Password**: Admin123!

## Steps to Log In:

1. Go to the login page: [Login](https://8000-d5147d01-4383-4923-9751-4d2b1ffee9ec.h1141.daytona.work/login.html)
2. Enter the admin credentials:
   - Email: admin@recipegoblin.com
   - Password: Admin123!
3. Click "Log In"
4. After logging in, navigate to the admin panel: [Admin Dashboard](https://8000-d5147d01-4383-4923-9751-4d2b1ffee9ec.h1141.daytona.work/admin/index.html)

## Admin Features:

Once logged in as admin, you can:
- View site statistics on the dashboard
- Manage user accounts (add, edit, delete)
- Control user registration status
- View and manage recipes