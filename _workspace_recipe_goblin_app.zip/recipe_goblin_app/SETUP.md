# Recipe Goblin Setup Guide

This document provides instructions for setting up and deploying the Recipe Goblin application.

## Prerequisites

- Web server (Apache, Nginx, or any static file server)
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Basic knowledge of HTML/CSS/JavaScript for customization

## Installation

### Local Installation

1. **Download the files**
   - Clone the repository or download the ZIP file
   - Extract the files to your desired location

2. **Run locally**
   - Open `index.html` in your web browser
   - For a better experience, use a local server:
     ```
     # Using Python
     python -m http.server 8000
     
     # Using Node.js
     npx serve
     ```

3. **Test functionality**
   - Register a new user account
   - Try generating recipes
   - Access the admin panel at `/admin/index.html`

### Web Server Deployment

1. **Upload files**
   - Upload all files to your web server
   - Ensure proper file permissions (typically 644 for files, 755 for directories)

2. **Configure web server** (if needed)
   - For Apache, ensure `.htaccess` is properly configured
   - For Nginx, configure to serve static files

3. **Access the application**
   - Navigate to your domain where the files are hosted
   - The app should load the home page

## Configuration

### Admin Account Setup

1. **Create initial admin user**
   - Register a new user through the registration page
   - Open the browser's developer tools (F12)
   - Go to the "Application" tab
   - Under "Storage" > "Local Storage", find your site
   - Edit the user entry to change the role to "admin":
     ```json
     {
       "fullname": "Admin User",
       "email": "admin@example.com",
       "password": "base64encodedpassword",
       "role": "admin",
       "status": "active",
       "createdAt": "2025-08-27T07:06:27.000Z"
     }
     ```

2. **Access admin panel**
   - Log in with your admin credentials
   - Navigate to `/admin/index.html`
   - You should now have access to all admin features

### Customization

1. **Branding**
   - Replace the logo in `/images/logo.svg`
   - Update color scheme in `/css/styles.css` by modifying the CSS variables in the `:root` selector
   - Change site name and footer information in HTML files

2. **Content**
   - Modify default recipe categories in `/js/app.js`
   - Update sample content in HTML files

3. **Features**
   - Enable/disable features by commenting out relevant sections in HTML and JS files

## Production Considerations

For a production environment, consider implementing the following:

1. **Backend Integration**
   - Replace LocalStorage with a proper database
   - Implement server-side authentication
   - Add API endpoints for data operations

2. **Security Enhancements**
   - Implement proper password hashing
   - Add CSRF protection
   - Set up proper session management

3. **Performance Optimization**
   - Minify CSS and JavaScript files
   - Optimize images
   - Implement caching strategies

4. **Analytics**
   - Add Google Analytics or similar tracking
   - Implement more detailed user activity tracking

## Troubleshooting

### Common Issues

1. **Login problems**
   - Clear browser cache and local storage
   - Ensure cookies are enabled
   - Check for console errors in browser developer tools

2. **Admin access issues**
   - Verify user role is set to "admin" in local storage
   - Check for JavaScript errors in console
   - Ensure all files are properly loaded

3. **Recipe generator not working**
   - Check browser console for errors
   - Ensure JavaScript is enabled
   - Verify all dependencies are loaded

### Support

For additional support:
- Check the README.md file for more information
- Contact the developer at support@recipegoblin.com (example email)

## Updates and Maintenance

1. **Backup regularly**
   - Export user data from local storage if needed
   - Keep copies of any customizations

2. **Check for updates**
   - Visit the repository for latest versions
   - Follow the update instructions provided with new releases

3. **Testing**
   - Always test in a staging environment before updating production
   - Verify all features work after updates