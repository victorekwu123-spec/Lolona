// Create Admin Account Script

// Admin user data
const adminUser = {
    fullname: "Admin User",
    email: "admin@recipegoblin.com",
    password: btoa("Admin123!"), // Base64 encoded password
    role: "admin",
    status: "active",
    createdAt: new Date().toISOString(),
    lastActive: new Date().toISOString()
};

// Get existing users or create empty array
let users = JSON.parse(localStorage.getItem('recipeGoblinUsers') || '[]');

// Check if admin already exists
const adminExists = users.some(user => user.email === adminUser.email);

if (!adminExists) {
    // Add admin to users array
    users.push(adminUser);
    
    // Save to localStorage
    localStorage.setItem('recipeGoblinUsers', JSON.stringify(users));
    
    console.log('Admin account created successfully!');
} else {
    console.log('Admin account already exists.');
}

// Set current user to admin for immediate access
localStorage.setItem('recipeGoblinCurrentUser', JSON.stringify({
    fullname: adminUser.fullname,
    email: adminUser.email,
    createdAt: adminUser.createdAt
}));

console.log('Admin user set as current user.');