// User Management JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize user management
    initUserManagement();
});

// Sample user data for demonstration
const sampleUsers = [
    {
        id: 1,
        fullname: 'John Doe',
        email: 'john@example.com',
        role: 'admin',
        status: 'active',
        joined: '2025-07-15T10:30:00',
        lastActive: '2025-08-26T14:45:00',
        avatar: 'https://source.unsplash.com/random/100x100/?portrait,man'
    },
    {
        id: 2,
        fullname: 'Jane Smith',
        email: 'jane@example.com',
        role: 'editor',
        status: 'active',
        joined: '2025-07-20T09:15:00',
        lastActive: '2025-08-25T16:30:00',
        avatar: 'https://source.unsplash.com/random/100x100/?portrait,woman'
    },
    {
        id: 3,
        fullname: 'Robert Johnson',
        email: 'robert@example.com',
        role: 'user',
        status: 'pending',
        joined: '2025-08-05T14:20:00',
        lastActive: null,
        avatar: 'https://source.unsplash.com/random/100x100/?portrait,man,2'
    },
    {
        id: 4,
        fullname: 'Emily Davis',
        email: 'emily@example.com',
        role: 'user',
        status: 'active',
        joined: '2025-08-10T11:45:00',
        lastActive: '2025-08-24T10:15:00',
        avatar: 'https://source.unsplash.com/random/100x100/?portrait,woman,2'
    },
    {
        id: 5,
        fullname: 'Michael Wilson',
        email: 'michael@example.com',
        role: 'editor',
        status: 'blocked',
        joined: '2025-07-25T08:30:00',
        lastActive: '2025-08-15T09:20:00',
        avatar: 'https://source.unsplash.com/random/100x100/?portrait,man,3'
    }
];

// Global variables
let users = [];
let currentPage = 1;
let itemsPerPage = 10;
let totalPages = 1;
let filters = {
    status: 'all',
    role: 'all',
    date: 'all',
    search: ''
};
let currentUserId = null;

function initUserManagement() {
    // Load users from localStorage or use sample data
    loadUsers();
    
    // Update stats
    updateUserStats();
    
    // Render users table
    renderUsersTable();
    
    // Set up event listeners
    setupUserManagementEvents();
    
    console.log('User management initialized successfully!');
}

function loadUsers() {
    // Try to load users from localStorage
    const storedUsers = localStorage.getItem('recipeGoblinUsers');
    
    if (storedUsers) {
        // Parse stored users and map to our format
        const parsedUsers = JSON.parse(storedUsers);
        users = parsedUsers.map((user, index) => {
            return {
                id: index + 1,
                fullname: user.fullname,
                email: user.email,
                role: user.role || 'user',
                status: user.status || 'active',
                joined: user.createdAt || new Date().toISOString(),
                lastActive: user.lastActive || null,
                avatar: `https://source.unsplash.com/random/100x100/?portrait,${index}`
            };
        });
    } else {
        // Use sample data if no stored users
        users = [...sampleUsers];
    }
}

function updateUserStats() {
    // Update total users count
    document.getElementById('total-users').textContent = users.length;
    
    // Calculate new users this month
    const now = new Date();
    const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const newUsersCount = users.filter(user => {
        const joinedDate = new Date(user.joined);
        return joinedDate >= firstDayOfMonth;
    }).length;
    document.getElementById('new-users').textContent = newUsersCount;
    
    // Calculate active users
    const activeUsersCount = users.filter(user => user.status === 'active').length;
    document.getElementById('active-users').textContent = activeUsersCount;
    
    // Calculate pending users
    const pendingUsersCount = users.filter(user => user.status === 'pending').length;
    document.getElementById('pending-users').textContent = pendingUsersCount;
}

function renderUsersTable() {
    const tableBody = document.getElementById('users-table-body');
    tableBody.innerHTML = '';
    
    // Apply filters
    const filteredUsers = filterUsers();
    
    // Calculate pagination
    totalPages = Math.ceil(filteredUsers.length / itemsPerPage);
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = Math.min(startIndex + itemsPerPage, filteredUsers.length);
    const paginatedUsers = filteredUsers.slice(startIndex, endIndex);
    
    // Update pagination info
    document.getElementById('showing-start').textContent = filteredUsers.length > 0 ? startIndex + 1 : 0;
    document.getElementById('showing-end').textContent = endIndex;
    document.getElementById('total-items').textContent = filteredUsers.length;
    
    // Render pagination controls
    renderPagination();
    
    // Check if no users found
    if (paginatedUsers.length === 0) {
        const noDataRow = document.createElement('tr');
        noDataRow.innerHTML = `
            <td colspan="8" class="text-center">
                <div class="no-data">
                    <i class="fas fa-users-slash"></i>
                    <p>No users found</p>
                </div>
            </td>
        `;
        tableBody.appendChild(noDataRow);
        return;
    }
    
    // Render user rows
    paginatedUsers.forEach(user => {
        const row = document.createElement('tr');
        row.dataset.id = user.id;
        
        row.innerHTML = `
            <td>
                <input type="checkbox" class="user-checkbox" data-id="${user.id}">
            </td>
            <td>
                <div class="user-info">
                    <img src="${user.avatar}" alt="${user.fullname}" class="user-avatar">
                    <div>
                        <div class="user-name">${user.fullname}</div>
                        <div class="user-role">${capitalizeFirstLetter(user.role)}</div>
                    </div>
                </div>
            </td>
            <td>${user.email}</td>
            <td>${capitalizeFirstLetter(user.role)}</td>
            <td>
                <span class="status-badge status-${user.status}">${capitalizeFirstLetter(user.status)}</span>
            </td>
            <td>${formatDate(user.joined)}</td>
            <td>${user.lastActive ? formatDate(user.lastActive) : 'Never'}</td>
            <td>
                <div class="table-actions">
                    <button class="action-btn edit" data-id="${user.id}" title="Edit User">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn delete" data-id="${user.id}" title="Delete User">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </div>
            </td>
        `;
        
        tableBody.appendChild(row);
    });
}

function filterUsers() {
    return users.filter(user => {
        // Status filter
        if (filters.status !== 'all' && user.status !== filters.status) {
            return false;
        }
        
        // Role filter
        if (filters.role !== 'all' && user.role !== filters.role) {
            return false;
        }
        
        // Date filter
        if (filters.date !== 'all') {
            const joinedDate = new Date(user.joined);
            const now = new Date();
            
            if (filters.date === 'today') {
                const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
                if (joinedDate < today) {
                    return false;
                }
            } else if (filters.date === 'week') {
                const weekAgo = new Date(now);
                weekAgo.setDate(now.getDate() - 7);
                if (joinedDate < weekAgo) {
                    return false;
                }
            } else if (filters.date === 'month') {
                const monthAgo = new Date(now);
                monthAgo.setMonth(now.getMonth() - 1);
                if (joinedDate < monthAgo) {
                    return false;
                }
            } else if (filters.date === 'year') {
                const yearAgo = new Date(now);
                yearAgo.setFullYear(now.getFullYear() - 1);
                if (joinedDate < yearAgo) {
                    return false;
                }
            }
        }
        
        // Search filter
        if (filters.search) {
            const searchTerm = filters.search.toLowerCase();
            return (
                user.fullname.toLowerCase().includes(searchTerm) ||
                user.email.toLowerCase().includes(searchTerm) ||
                user.role.toLowerCase().includes(searchTerm)
            );
        }
        
        return true;
    });
}

function renderPagination() {
    const paginationContainer = document.getElementById('pagination-pages');
    paginationContainer.innerHTML = '';
    
    // Update prev/next buttons
    document.getElementById('prev-page').disabled = currentPage === 1;
    document.getElementById('next-page').disabled = currentPage === totalPages || totalPages === 0;
    
    // Don't render pagination if no pages
    if (totalPages === 0) {
        return;
    }
    
    // Determine which page buttons to show
    let startPage = Math.max(1, currentPage - 2);
    let endPage = Math.min(totalPages, startPage + 4);
    
    if (endPage - startPage < 4) {
        startPage = Math.max(1, endPage - 4);
    }
    
    // First page button
    if (startPage > 1) {
        const firstPageBtn = document.createElement('button');
        firstPageBtn.className = 'page-btn';
        firstPageBtn.textContent = '1';
        firstPageBtn.dataset.page = 1;
        paginationContainer.appendChild(firstPageBtn);
        
        if (startPage > 2) {
            const ellipsis = document.createElement('span');
            ellipsis.className = 'pagination-ellipsis';
            ellipsis.textContent = '...';
            paginationContainer.appendChild(ellipsis);
        }
    }
    
    // Page buttons
    for (let i = startPage; i <= endPage; i++) {
        const pageBtn = document.createElement('button');
        pageBtn.className = `page-btn ${i === currentPage ? 'active' : ''}`;
        pageBtn.textContent = i;
        pageBtn.dataset.page = i;
        paginationContainer.appendChild(pageBtn);
    }
    
    // Last page button
    if (endPage < totalPages) {
        if (endPage < totalPages - 1) {
            const ellipsis = document.createElement('span');
            ellipsis.className = 'pagination-ellipsis';
            ellipsis.textContent = '...';
            paginationContainer.appendChild(ellipsis);
        }
        
        const lastPageBtn = document.createElement('button');
        lastPageBtn.className = 'page-btn';
        lastPageBtn.textContent = totalPages;
        lastPageBtn.dataset.page = totalPages;
        paginationContainer.appendChild(lastPageBtn);
    }
}

function setupUserManagementEvents() {
    // Filter change events
    document.getElementById('status-filter').addEventListener('change', function() {
        filters.status = this.value;
        currentPage = 1;
        renderUsersTable();
    });
    
    document.getElementById('role-filter').addEventListener('change', function() {
        filters.role = this.value;
        currentPage = 1;
        renderUsersTable();
    });
    
    document.getElementById('date-filter').addEventListener('change', function() {
        filters.date = this.value;
        currentPage = 1;
        renderUsersTable();
    });
    
    // Search input
    document.getElementById('search-users').addEventListener('input', function() {
        filters.search = this.value;
        currentPage = 1;
        renderUsersTable();
    });
    
    // Pagination events
    document.getElementById('prev-page').addEventListener('click', function() {
        if (currentPage > 1) {
            currentPage--;
            renderUsersTable();
        }
    });
    
    document.getElementById('next-page').addEventListener('click', function() {
        if (currentPage < totalPages) {
            currentPage++;
            renderUsersTable();
        }
    });
    
    document.getElementById('pagination-pages').addEventListener('click', function(e) {
        if (e.target.classList.contains('page-btn')) {
            currentPage = parseInt(e.target.dataset.page);
            renderUsersTable();
        }
    });
    
    // Select all checkbox
    document.getElementById('select-all').addEventListener('change', function() {
        const checkboxes = document.querySelectorAll('.user-checkbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = this.checked;
        });
    });
    
    // Table action buttons
    document.getElementById('users-table-body').addEventListener('click', function(e) {
        // Edit button
        if (e.target.closest('.action-btn.edit')) {
            const userId = e.target.closest('.action-btn.edit').dataset.id;
            openEditUserModal(userId);
        }
        
        // Delete button
        if (e.target.closest('.action-btn.delete')) {
            const userId = e.target.closest('.action-btn.delete').dataset.id;
            openDeleteUserModal(userId);
        }
    });
    
    // Add user button
    document.getElementById('add-user-btn').addEventListener('click', function() {
        openAddUserModal();
    });
    
    // User form submission
    document.getElementById('save-user').addEventListener('click', function() {
        saveUser();
    });
    
    // Cancel user form
    document.getElementById('cancel-user').addEventListener('click', function() {
        closeUserModal();
    });
    
    // Delete confirmation
    document.getElementById('confirm-delete').addEventListener('click', function() {
        deleteUser();
    });
    
    // Cancel delete
    document.getElementById('cancel-delete').addEventListener('click', function() {
        closeDeleteModal();
    });
    
    // Modal close buttons
    document.querySelectorAll('.modal-close').forEach(btn => {
        btn.addEventListener('click', function() {
            const modal = this.closest('.modal');
            if (modal.id === 'user-modal') {
                closeUserModal();
            } else if (modal.id === 'delete-modal') {
                closeDeleteModal();
            }
        });
    });
    
    // Toggle password visibility
    const togglePasswordBtn = document.querySelector('.toggle-password');
    if (togglePasswordBtn) {
        togglePasswordBtn.addEventListener('click', function() {
            const passwordInput = document.getElementById('user-password');
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            
            // Toggle icon
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });
    }
    
    // Sidebar toggle
    document.querySelector('.sidebar-toggle').addEventListener('click', function() {
        document.querySelector('.admin-sidebar').classList.toggle('collapsed');
    });
}

function openAddUserModal() {
    // Reset form
    document.getElementById('user-form').reset();
    document.getElementById('user-id').value = '';
    document.getElementById('modal-title').textContent = 'Add New User';
    
    // Show password field
    document.getElementById('user-password').setAttribute('required', 'required');
    document.getElementById('user-password').parentElement.parentElement.style.display = 'block';
    
    // Show modal
    document.getElementById('user-modal').classList.add('show');
    
    // Reset current user ID
    currentUserId = null;
}

function openEditUserModal(userId) {
    // Find user
    const user = users.find(u => u.id == userId);
    if (!user) return;
    
    // Set form values
    document.getElementById('user-id').value = user.id;
    document.getElementById('user-fullname').value = user.fullname;
    document.getElementById('user-email').value = user.email;
    document.getElementById('user-role').value = user.role;
    document.getElementById('user-status').value = user.status;
    
    // Password is not filled for security
    document.getElementById('user-password').value = '';
    document.getElementById('user-password').removeAttribute('required');
    
    // Update modal title
    document.getElementById('modal-title').textContent = 'Edit User';
    
    // Show modal
    document.getElementById('user-modal').classList.add('show');
    
    // Set current user ID
    currentUserId = user.id;
}

function closeUserModal() {
    document.getElementById('user-modal').classList.remove('show');
}

function openDeleteUserModal(userId) {
    // Find user
    const user = users.find(u => u.id == userId);
    if (!user) return;
    
    // Set user info in modal
    document.getElementById('delete-user-name').textContent = user.fullname;
    document.getElementById('delete-user-email').textContent = user.email;
    
    // Show modal
    document.getElementById('delete-modal').classList.add('show');
    
    // Set current user ID
    currentUserId = user.id;
}

function closeDeleteModal() {
    document.getElementById('delete-modal').classList.remove('show');
    currentUserId = null;
}

function saveUser() {
    // Get form values
    const userId = document.getElementById('user-id').value;
    const fullname = document.getElementById('user-fullname').value;
    const email = document.getElementById('user-email').value;
    const password = document.getElementById('user-password').value;
    const role = document.getElementById('user-role').value;
    const status = document.getElementById('user-status').value;
    const sendWelcomeEmail = document.getElementById('send-welcome-email').checked;
    
    // Validate form
    if (!fullname || !email) {
        alert('Please fill in all required fields');
        return;
    }
    
    // Check if adding new user
    if (!userId) {
        // Validate password for new users
        if (!password) {
            alert('Password is required for new users');
            return;
        }
        
        // Check if email already exists
        if (users.some(u => u.email === email)) {
            alert('A user with this email already exists');
            return;
        }
        
        // Create new user
        const newUser = {
            id: users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1,
            fullname,
            email,
            role,
            status,
            joined: new Date().toISOString(),
            lastActive: null,
            avatar: `https://source.unsplash.com/random/100x100/?portrait,${Math.random()}`
        };
        
        // Add to users array
        users.push(newUser);
        
        // Save to localStorage
        saveUsersToLocalStorage();
        
        // Show success message
        alert('User added successfully');
    } else {
        // Update existing user
        const userIndex = users.findIndex(u => u.id == userId);
        if (userIndex === -1) {
            alert('User not found');
            return;
        }
        
        // Check if email already exists (excluding current user)
        if (users.some(u => u.email === email && u.id != userId)) {
            alert('A user with this email already exists');
            return;
        }
        
        // Update user
        users[userIndex] = {
            ...users[userIndex],
            fullname,
            email,
            role,
            status
        };
        
        // Save to localStorage
        saveUsersToLocalStorage();
        
        // Show success message
        alert('User updated successfully');
    }
    
    // Close modal
    closeUserModal();
    
    // Update stats and table
    updateUserStats();
    renderUsersTable();
    
    // Simulate sending welcome email
    if (sendWelcomeEmail) {
        console.log(`Welcome email would be sent to ${email}`);
    }
}

function deleteUser() {
    if (!currentUserId) return;
    
    // Find user index
    const userIndex = users.findIndex(u => u.id == currentUserId);
    if (userIndex === -1) {
        alert('User not found');
        return;
    }
    
    // Remove user
    users.splice(userIndex, 1);
    
    // Save to localStorage
    saveUsersToLocalStorage();
    
    // Close modal
    closeDeleteModal();
    
    // Update stats and table
    updateUserStats();
    renderUsersTable();
    
    // Show success message
    alert('User deleted successfully');
}

function saveUsersToLocalStorage() {
    // Convert users to the format expected by the app
    const appUsers = users.map(user => {
        return {
            fullname: user.fullname,
            email: user.email,
            password: btoa('password123'), // Default password for demo
            role: user.role,
            status: user.status,
            createdAt: user.joined,
            lastActive: user.lastActive
        };
    });
    
    localStorage.setItem('recipeGoblinUsers', JSON.stringify(appUsers));
}

// Utility functions
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric'
    });
}

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}