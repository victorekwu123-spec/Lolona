// Authentication JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize authentication components
    initAuth();
});

function initAuth() {
    // Set up event listeners
    setupAuthEvents();
    
    // Initialize password strength meter if on register page
    if (document.getElementById('register-form')) {
        initPasswordStrength();
    }
    
    console.log('Authentication initialized successfully!');
}

function setupAuthEvents() {
    // Mobile menu toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu');
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', function() {
            const navMenu = document.querySelector('.nav-menu');
            navMenu.classList.toggle('show');
        });
    }
    
    // Toggle password visibility
    const togglePasswordBtns = document.querySelectorAll('.toggle-password');
    togglePasswordBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const passwordInput = this.previousElementSibling;
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            
            // Toggle icon
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });
    });
    
    // Register form submission
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const fullname = document.getElementById('fullname').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm-password').value;
            const terms = document.getElementById('terms').checked;
            
            // Validate form
            if (!validateRegisterForm(fullname, email, password, confirmPassword, terms)) {
                return;
            }
            
            // Simulate API call with setTimeout
            showLoadingState(registerForm);
            
            setTimeout(() => {
                // Store user data in localStorage (for demo purposes only)
                const userData = {
                    fullname,
                    email,
                    password: btoa(password), // Base64 encoding (NOT secure, just for demo)
                    createdAt: new Date().toISOString()
                };
                
                // Check if email already exists
                const existingUsers = JSON.parse(localStorage.getItem('recipeGoblinUsers') || '[]');
                const emailExists = existingUsers.some(user => user.email === email);
                
                if (emailExists) {
                    hideLoadingState(registerForm);
                    showAuthAlert('This email is already registered. Please log in instead.', 'error');
                    return;
                }
                
                // Save user
                existingUsers.push(userData);
                localStorage.setItem('recipeGoblinUsers', JSON.stringify(existingUsers));
                
                // Set current user
                localStorage.setItem('recipeGoblinCurrentUser', JSON.stringify({
                    fullname,
                    email,
                    createdAt: userData.createdAt
                }));
                
                // Show success message
                hideLoadingState(registerForm);
                showAuthAlert('Registration successful! Redirecting to dashboard...', 'success');
                
                // Redirect to dashboard after delay
                setTimeout(() => {
                    window.location.href = 'dashboard.html';
                }, 1500);
            }, 1500);
        });
    }
    
    // Login form submission
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const remember = document.getElementById('remember')?.checked || false;
            
            // Validate form
            if (!validateLoginForm(email, password)) {
                return;
            }
            
            // Simulate API call with setTimeout
            showLoadingState(loginForm);
            
            setTimeout(() => {
                // Check credentials against localStorage (for demo purposes only)
                const existingUsers = JSON.parse(localStorage.getItem('recipeGoblinUsers') || '[]');
                const user = existingUsers.find(user => user.email === email && atob(user.password) === password);
                
                if (!user) {
                    hideLoadingState(loginForm);
                    showAuthAlert('Invalid email or password. Please try again.', 'error');
                    return;
                }
                
                // Set current user
                localStorage.setItem('recipeGoblinCurrentUser', JSON.stringify({
                    fullname: user.fullname,
                    email: user.email,
                    createdAt: user.createdAt
                }));
                
                // Set remember me
                if (remember) {
                    localStorage.setItem('recipeGoblinRememberMe', 'true');
                } else {
                    localStorage.removeItem('recipeGoblinRememberMe');
                }
                
                // Show success message
                hideLoadingState(loginForm);
                showAuthAlert('Login successful! Redirecting to dashboard...', 'success');
                
                // Redirect to dashboard after delay
                setTimeout(() => {
                    window.location.href = 'dashboard.html';
                }, 1500);
            }, 1500);
        });
    }
    
    // Social auth buttons
    const socialButtons = document.querySelectorAll('.btn-social');
    socialButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            // Show alert for demo purposes
            showAuthAlert('Social login is not implemented in this demo.', 'info');
        });
    });
}

function initPasswordStrength() {
    const passwordInput = document.getElementById('password');
    const strengthBar = document.querySelector('.strength-fill');
    const strengthText = document.querySelector('.strength-text');
    
    passwordInput.addEventListener('input', function() {
        const password = this.value;
        const strength = calculatePasswordStrength(password);
        
        // Update strength bar
        strengthBar.style.width = `${strength.score * 25}%`;
        
        // Remove previous classes
        strengthBar.classList.remove('weak', 'medium', 'strong');
        
        // Add appropriate class
        if (strength.score > 0) {
            strengthBar.classList.add(strength.level);
        }
        
        // Update text
        strengthText.textContent = password ? `Password strength: ${strength.level}` : 'Password strength';
    });
}

function calculatePasswordStrength(password) {
    // Simple password strength calculation
    if (!password) {
        return { score: 0, level: '' };
    }
    
    let score = 0;
    
    // Length check
    if (password.length >= 8) score += 1;
    if (password.length >= 12) score += 1;
    
    // Complexity checks
    if (/[A-Z]/.test(password)) score += 1;
    if (/[a-z]/.test(password)) score += 1;
    if (/[0-9]/.test(password)) score += 1;
    if (/[^A-Za-z0-9]/.test(password)) score += 1;
    
    // Determine level
    let level = '';
    if (score <= 2) level = 'weak';
    else if (score <= 4) level = 'medium';
    else level = 'strong';
    
    return { score: Math.min(score, 4), level };
}

function validateRegisterForm(fullname, email, password, confirmPassword, terms) {
    // Clear previous error messages
    clearValidationErrors();
    
    let isValid = true;
    
    // Validate fullname
    if (!fullname.trim()) {
        showValidationError('fullname', 'Please enter your full name');
        isValid = false;
    }
    
    // Validate email
    if (!isValidEmail(email)) {
        showValidationError('email', 'Please enter a valid email address');
        isValid = false;
    }
    
    // Validate password
    if (password.length < 8) {
        showValidationError('password', 'Password must be at least 8 characters');
        isValid = false;
    }
    
    // Validate confirm password
    if (password !== confirmPassword) {
        showValidationError('confirm-password', 'Passwords do not match');
        isValid = false;
    }
    
    // Validate terms
    if (!terms) {
        showValidationError('terms', 'You must agree to the Terms of Service');
        isValid = false;
    }
    
    return isValid;
}

function validateLoginForm(email, password) {
    // Clear previous error messages
    clearValidationErrors();
    
    let isValid = true;
    
    // Validate email
    if (!isValidEmail(email)) {
        showValidationError('email', 'Please enter a valid email address');
        isValid = false;
    }
    
    // Validate password
    if (!password) {
        showValidationError('password', 'Please enter your password');
        isValid = false;
    }
    
    return isValid;
}

function isValidEmail(email) {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

function showValidationError(inputId, message) {
    const input = document.getElementById(inputId);
    input.classList.add('is-invalid');
    
    // Create error message element
    const errorDiv = document.createElement('div');
    errorDiv.className = 'invalid-feedback';
    errorDiv.textContent = message;
    
    // Add error message after input or its parent for checkboxes
    if (input.type === 'checkbox') {
        input.parentElement.appendChild(errorDiv);
    } else {
        input.parentElement.appendChild(errorDiv);
    }
}

function clearValidationErrors() {
    // Remove all error classes and messages
    document.querySelectorAll('.is-invalid').forEach(el => {
        el.classList.remove('is-invalid');
    });
    
    document.querySelectorAll('.invalid-feedback').forEach(el => {
        el.remove();
    });
}

function showAuthAlert(message, type = 'info') {
    // Remove any existing alerts
    const existingAlert = document.querySelector('.auth-alert');
    if (existingAlert) {
        existingAlert.remove();
    }
    
    // Create alert element
    const alertDiv = document.createElement('div');
    alertDiv.className = `auth-alert ${type}`;
    
    // Add icon based on type
    let icon = 'info-circle';
    if (type === 'success') icon = 'check-circle';
    if (type === 'error') icon = 'exclamation-circle';
    
    alertDiv.innerHTML = `<i class="fas fa-${icon}"></i> ${message}`;
    
    // Add to DOM before the form
    const form = document.querySelector('.auth-form');
    form.parentElement.insertBefore(alertDiv, form);
    
    // Remove after delay for success messages
    if (type === 'success') {
        setTimeout(() => {
            alertDiv.remove();
        }, 5000);
    }
}

function showLoadingState(form) {
    // Disable all inputs and buttons
    form.querySelectorAll('input, button').forEach(el => {
        el.setAttribute('disabled', 'disabled');
    });
    
    // Change submit button text
    const submitBtn = form.querySelector('button[type="submit"]');
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
}

function hideLoadingState(form) {
    // Enable all inputs and buttons
    form.querySelectorAll('input, button').forEach(el => {
        el.removeAttribute('disabled');
    });
    
    // Restore submit button text
    const submitBtn = form.querySelector('button[type="submit"]');
    const isRegister = form.id === 'register-form';
    submitBtn.innerHTML = isRegister ? 'Create Account' : 'Log In';
}

// Check if user is already logged in
function checkAuthStatus() {
    const currentUser = localStorage.getItem('recipeGoblinCurrentUser');
    const rememberMe = localStorage.getItem('recipeGoblinRememberMe');
    
    if (currentUser && rememberMe) {
        // User is logged in and has remember me enabled
        // Redirect to dashboard if on login or register page
        const path = window.location.pathname;
        if (path.includes('login.html') || path.includes('register.html')) {
            window.location.href = 'dashboard.html';
        }
    }
}

// Call on page load
checkAuthStatus();