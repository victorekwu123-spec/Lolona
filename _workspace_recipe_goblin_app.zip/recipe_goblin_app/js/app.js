// Cooking Blog App - Main JavaScript File

// DOM Elements
document.addEventListener('DOMContentLoaded', function() {
    // Initialize the application
    initApp();
});

// Global Variables
const recipeData = {
    savedRecipes: [],
    generatedRecipes: []
};

// Initialize Application
function initApp() {
    // Set up event listeners
    setupEventListeners();
    
    // Load any saved data from localStorage
    loadSavedData();
    
    // Initialize UI components
    initializeUI();
    
    console.log('Cooking Blog App initialized successfully!');
}

// Set up event listeners
function setupEventListeners() {
    // Recipe Generator Form
    const generatorForm = document.getElementById('recipe-generator-form');
    if (generatorForm) {
        generatorForm.addEventListener('submit', handleRecipeGeneration);
    }
    
    // Mobile Menu Toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu');
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', toggleMobileMenu);
    }
    
    // Recipe Card Clicks
    document.addEventListener('click', function(e) {
        if (e.target.closest('.recipe-card')) {
            const recipeCard = e.target.closest('.recipe-card');
            const recipeId = recipeCard.dataset.id;
            if (recipeId) {
                viewRecipeDetails(recipeId);
            }
        }
    });
}

// Load saved data from localStorage
function loadSavedData() {
    try {
        const savedData = localStorage.getItem('cookingBlogAppData');
        if (savedData) {
            const parsedData = JSON.parse(savedData);
            if (parsedData.savedRecipes) {
                recipeData.savedRecipes = parsedData.savedRecipes;
            }
            if (parsedData.generatedRecipes) {
                recipeData.generatedRecipes = parsedData.generatedRecipes;
            }
        }
    } catch (error) {
        console.error('Error loading saved data:', error);
    }
}

// Save data to localStorage
function saveData() {
    try {
        localStorage.setItem('cookingBlogAppData', JSON.stringify(recipeData));
    } catch (error) {
        console.error('Error saving data:', error);
    }
}

// Initialize UI components
function initializeUI() {
    // Update recipe cards if on home page
    const recipesContainer = document.querySelector('.recipes-container');
    if (recipesContainer) {
        displaySavedRecipes(recipesContainer);
    }
    
    // Update dashboard stats if on dashboard page
    const dashboardStats = document.querySelector('.stats-container');
    if (dashboardStats) {
        updateDashboardStats();
    }
}

// Toggle mobile menu
function toggleMobileMenu() {
    const navMenu = document.querySelector('.nav-menu');
    if (navMenu) {
        navMenu.classList.toggle('show');
    }
}

// Handle recipe generation form submission
function handleRecipeGeneration(e) {
    e.preventDefault();
    
    // Get form values
    const recipeTitle = document.getElementById('recipe-title').value;
    const recipeType = document.getElementById('recipe-type').value;
    const numItems = parseInt(document.getElementById('num-items').value) || 5;
    
    // Validate input
    if (!recipeTitle) {
        showAlert('Please enter a recipe title', 'error');
        return;
    }
    
    // Show loading state
    const previewContainer = document.querySelector('.generator-preview');
    if (previewContainer) {
        previewContainer.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i><p>Generating your recipe...</p></div>';
    }
    
    // Simulate API call with setTimeout
    setTimeout(() => {
        // Generate recipe
        const generatedRecipe = generateRecipe(recipeTitle, recipeType, numItems);
        
        // Display generated recipe
        displayGeneratedRecipe(generatedRecipe);
        
        // Save to generated recipes
        recipeData.generatedRecipes.push(generatedRecipe);
        saveData();
        
        // Show success message
        showAlert('Recipe generated successfully!', 'success');
    }, 1500);
}

// Generate a recipe (simulated AI generation)
function generateRecipe(title, type, numItems) {
    // Create recipe object
    const recipe = {
        id: Date.now().toString(),
        title: title,
        type: type,
        date: new Date().toISOString(),
        items: [],
        description: `Discover the best ${title.toLowerCase()} recipes that are perfect for any occasion. These ${type.toLowerCase()} recipes are easy to make and delicious.`
    };
    
    // Generate recipe items based on type
    const itemTypes = {
        breakfast: ['Pancakes', 'Waffles', 'Omelette', 'Smoothie Bowl', 'Avocado Toast', 'French Toast', 'Breakfast Burrito', 'Granola Parfait'],
        lunch: ['Sandwich', 'Salad', 'Soup', 'Wrap', 'Bowl', 'Pasta', 'Stir Fry', 'Quesadilla'],
        dinner: ['Pasta', 'Steak', 'Chicken', 'Fish', 'Vegetarian', 'Casserole', 'Stir Fry', 'Curry'],
        dessert: ['Cake', 'Cookies', 'Ice Cream', 'Pie', 'Brownies', 'Pudding', 'Tart', 'Mousse'],
        snack: ['Dip', 'Chips', 'Nuts', 'Fruit', 'Popcorn', 'Energy Balls', 'Smoothie', 'Yogurt']
    };
    
    const itemDescriptions = {
        breakfast: [
            'Start your day right with this energizing recipe.',
            'A quick and nutritious breakfast option for busy mornings.',
            'This protein-packed breakfast will keep you full until lunch.',
            'A family favorite that kids and adults will love.',
            'Perfect for weekend brunch with friends and family.'
        ],
        lunch: [
            'A light and refreshing lunch option for busy days.',
            'Meal prep friendly and perfect for work lunches.',
            'This balanced lunch provides sustained energy all afternoon.',
            'Ready in under 15 minutes for those busy weekdays.',
            'Packed with nutrients and flavor in every bite.'
        ],
        dinner: [
            'A satisfying dinner that the whole family will enjoy.',
            'Impressive enough for guests but easy enough for weeknights.',
            'This comfort food classic never disappoints.',
            'A healthy dinner option that doesn't sacrifice flavor.',
            'Perfect for meal prepping for the week ahead.'
        ],
        dessert: [
            'Indulge your sweet tooth with this decadent dessert.',
            'A perfect ending to any meal.',
            'This crowd-pleaser is always a hit at gatherings.',
            'A lighter dessert option that still satisfies.',
            'This make-ahead dessert is perfect for entertaining.'
        ],
        snack: [
            'A healthy snack to keep energy levels up between meals.',
            'Perfect for on-the-go snacking.',
            'Kids and adults alike will love this tasty treat.',
            'A protein-packed snack to fuel your day.',
            'Satisfy cravings with this nutritious option.'
        ]
    };
    
    const selectedType = type.toLowerCase();
    const options = itemTypes[selectedType] || itemTypes.dinner;
    const descriptions = itemDescriptions[selectedType] || itemDescriptions.dinner;
    
    // Generate the specified number of items
    for (let i = 0; i < numItems; i++) {
        const itemName = options[Math.floor(Math.random() * options.length)];
        const itemDesc = descriptions[Math.floor(Math.random() * descriptions.length)];
        
        recipe.items.push({
            id: i + 1,
            name: `${itemName} ${title}`,
            description: itemDesc,
            imageUrl: `https://source.unsplash.com/random/300x200/?${itemName.toLowerCase()},${type.toLowerCase()},food`
        });
    }
    
    return recipe;
}

// Display generated recipe in preview container
function displayGeneratedRecipe(recipe) {
    const previewContainer = document.querySelector('.generator-preview');
    if (!previewContainer) return;
    
    let html = `
        <div class="generated-recipe animate-fade-in">
            <h3>${recipe.title}</h3>
            <p class="recipe-description">${recipe.description}</p>
            <div class="recipe-items">
    `;
    
    recipe.items.forEach(item => {
        html += `
            <div class="recipe-item">
                <h4>${item.id}. ${item.name}</h4>
                <div class="recipe-item-content">
                    <div class="recipe-item-image">
                        <img src="${item.imageUrl}" alt="${item.name}">
                    </div>
                    <p>${item.description}</p>
                </div>
            </div>
        `;
    });
    
    html += `
            </div>
            <div class="recipe-actions">
                <button class="btn btn-primary save-recipe" data-id="${recipe.id}">Save Recipe</button>
                <button class="btn btn-outline share-recipe" data-id="${recipe.id}">Share Recipe</button>
            </div>
        </div>
    `;
    
    previewContainer.innerHTML = html;
    
    // Add event listeners to the new buttons
    const saveBtn = previewContainer.querySelector('.save-recipe');
    if (saveBtn) {
        saveBtn.addEventListener('click', () => saveRecipe(recipe.id));
    }
    
    const shareBtn = previewContainer.querySelector('.share-recipe');
    if (shareBtn) {
        shareBtn.addEventListener('click', () => shareRecipe(recipe.id));
    }
}

// Save a recipe to saved recipes
function saveRecipe(recipeId) {
    const recipe = recipeData.generatedRecipes.find(r => r.id === recipeId);
    if (!recipe) return;
    
    // Check if already saved
    if (recipeData.savedRecipes.some(r => r.id === recipeId)) {
        showAlert('Recipe already saved!', 'info');
        return;
    }
    
    // Add to saved recipes
    recipeData.savedRecipes.push(recipe);
    saveData();
    
    // Show success message
    showAlert('Recipe saved successfully!', 'success');
    
    // Update UI if on home page
    const recipesContainer = document.querySelector('.recipes-container');
    if (recipesContainer) {
        displaySavedRecipes(recipesContainer);
    }
}

// Share a recipe (simulated)
function shareRecipe(recipeId) {
    const recipe = recipeData.generatedRecipes.find(r => r.id === recipeId) || 
                   recipeData.savedRecipes.find(r => r.id === recipeId);
    if (!recipe) return;
    
    // Simulate sharing functionality
    showAlert('Sharing feature coming soon!', 'info');
}

// Display saved recipes in container
function displaySavedRecipes(container) {
    if (recipeData.savedRecipes.length === 0) {
        container.innerHTML = `
            <div class="no-recipes">
                <i class="fas fa-utensils"></i>
                <p>No recipes saved yet. Generate some recipes to get started!</p>
            </div>
        `;
        return;
    }
    
    let html = '';
    
    recipeData.savedRecipes.forEach(recipe => {
        // Get the first item's image for the card
        const firstItemImage = recipe.items.length > 0 ? recipe.items[0].imageUrl : 'https://source.unsplash.com/random/300x200/?food';
        
        html += `
            <div class="recipe-card" data-id="${recipe.id}">
                <div class="recipe-image">
                    <img src="${firstItemImage}" alt="${recipe.title}">
                </div>
                <div class="recipe-content">
                    <h3>${recipe.title}</h3>
                    <div class="recipe-meta">
                        <span>${recipe.type}</span>
                        <span>${formatDate(recipe.date)}</span>
                    </div>
                    <p class="recipe-desc">${recipe.description}</p>
                    <div class="recipe-tags">
                        <span class="recipe-tag">${recipe.type}</span>
                        <span class="recipe-tag">${recipe.items.length} items</span>
                    </div>
                    <button class="btn btn-outline btn-sm view-recipe" data-id="${recipe.id}">View Recipe</button>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

// View recipe details
function viewRecipeDetails(recipeId) {
    const recipe = recipeData.savedRecipes.find(r => r.id === recipeId) || 
                   recipeData.generatedRecipes.find(r => r.id === recipeId);
    if (!recipe) return;
    
    // Redirect to recipe detail page (simulated)
    alert(`Viewing recipe: ${recipe.title}`);
    // In a real app, you would redirect to a detail page or show a modal
}

// Update dashboard statistics
function updateDashboardStats() {
    const statsContainer = document.querySelector('.stats-container');
    if (!statsContainer) return;
    
    const savedCount = recipeData.savedRecipes.length;
    const generatedCount = recipeData.generatedRecipes.length;
    
    const statsHtml = `
        <div class="stat-card">
            <h3>${savedCount}</h3>
            <p>Saved Recipes</p>
        </div>
        <div class="stat-card">
            <h3>${generatedCount}</h3>
            <p>Generated Recipes</p>
        </div>
        <div class="stat-card">
            <h3>${calculateTotalItems()}</h3>
            <p>Total Recipe Items</p>
        </div>
    `;
    
    statsContainer.innerHTML = statsHtml;
}

// Calculate total recipe items
function calculateTotalItems() {
    let total = 0;
    recipeData.savedRecipes.forEach(recipe => {
        total += recipe.items.length;
    });
    return total;
}

// Format date for display
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

// Show alert message
function showAlert(message, type = 'info') {
    // Create alert element
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    
    // Add to DOM
    document.body.appendChild(alertDiv);
    
    // Show with animation
    setTimeout(() => {
        alertDiv.classList.add('show');
    }, 10);
    
    // Remove after delay
    setTimeout(() => {
        alertDiv.classList.remove('show');
        setTimeout(() => {
            alertDiv.remove();
        }, 300);
    }, 3000);
}

// Additional utility functions for the app
// ...