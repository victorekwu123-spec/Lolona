// Recipe Detail Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize recipe detail page components
    initRecipeDetail();
});

function initRecipeDetail() {
    // Set up event listeners
    setupRecipeDetailEvents();
    
    // Initialize rating system
    initRatingSystem();
    
    console.log('Recipe detail page initialized successfully!');
}

function setupRecipeDetailEvents() {
    // Mobile menu toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu');
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', function() {
            const navMenu = document.querySelector('.nav-menu');
            navMenu.classList.toggle('show');
        });
    }
    
    // Print recipe button
    const printBtn = document.querySelector('.recipe-actions .btn-primary');
    if (printBtn) {
        printBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.print();
        });
    }
    
    // Save recipe button
    const saveBtn = document.querySelector('.recipe-actions .btn-outline:first-of-type');
    if (saveBtn) {
        saveBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Toggle saved state
            const isSaved = this.classList.contains('saved');
            
            if (isSaved) {
                // Remove saved state
                this.classList.remove('saved');
                this.innerHTML = '<i class="far fa-heart"></i> Save';
                showAlert('Recipe removed from saved recipes', 'info');
            } else {
                // Add saved state
                this.classList.add('saved');
                this.innerHTML = '<i class="fas fa-heart"></i> Saved';
                showAlert('Recipe saved to your collection!', 'success');
            }
        });
    }
    
    // Share recipe button
    const shareBtn = document.querySelector('.recipe-actions .btn-outline:last-of-type');
    if (shareBtn) {
        shareBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Check if Web Share API is supported
            if (navigator.share) {
                navigator.share({
                    title: 'Creamy Garlic Pasta Recipe',
                    text: 'Check out this delicious Creamy Garlic Pasta recipe I found!',
                    url: window.location.href
                })
                .then(() => console.log('Successful share'))
                .catch((error) => console.log('Error sharing:', error));
            } else {
                // Fallback for browsers that don't support the Web Share API
                // Create a temporary input to copy the URL
                const tempInput = document.createElement('input');
                tempInput.value = window.location.href;
                document.body.appendChild(tempInput);
                tempInput.select();
                document.execCommand('copy');
                document.body.removeChild(tempInput);
                
                showAlert('Recipe link copied to clipboard!', 'success');
            }
        });
    }
    
    // Review form submission
    const reviewForm = document.querySelector('.review-form');
    if (reviewForm) {
        reviewForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const rating = document.querySelectorAll('.rating-select i.active').length;
            const title = document.getElementById('review-title').value;
            const content = document.getElementById('review-content').value;
            
            // Validate input
            if (rating === 0) {
                showAlert('Please select a rating', 'error');
                return;
            }
            
            if (!title) {
                showAlert('Please enter a review title', 'error');
                return;
            }
            
            if (!content) {
                showAlert('Please enter your review', 'error');
                return;
            }
            
            // Simulate form submission
            showAlert('Your review has been submitted!', 'success');
            
            // Reset form
            document.querySelectorAll('.rating-select i').forEach(star => {
                star.classList.remove('active');
                star.classList.remove('fas');
                star.classList.add('far');
            });
            reviewForm.reset();
        });
    }
}

function initRatingSystem() {
    // Star rating selection
    const ratingStars = document.querySelectorAll('.rating-select i');
    if (ratingStars.length > 0) {
        ratingStars.forEach((star, index) => {
            star.addEventListener('mouseover', function() {
                // Reset all stars
                ratingStars.forEach(s => {
                    s.classList.remove('fas');
                    s.classList.add('far');
                });
                
                // Fill stars up to current
                for (let i = 0; i <= index; i++) {
                    ratingStars[i].classList.remove('far');
                    ratingStars[i].classList.add('fas');
                }
            });
            
            star.addEventListener('mouseout', function() {
                // Reset to active state
                ratingStars.forEach(s => {
                    if (s.classList.contains('active')) {
                        s.classList.remove('far');
                        s.classList.add('fas');
                    } else {
                        s.classList.remove('fas');
                        s.classList.add('far');
                    }
                });
            });
            
            star.addEventListener('click', function() {
                // Set active state
                ratingStars.forEach((s, i) => {
                    if (i <= index) {
                        s.classList.add('active');
                        s.classList.remove('far');
                        s.classList.add('fas');
                    } else {
                        s.classList.remove('active');
                        s.classList.remove('fas');
                        s.classList.add('far');
                    }
                });
            });
        });
    }
}

// Show alert message
function showAlert(message, type = 'info') {
    // Create alert element
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    
    // Add to DOM
    document.body.appendChild(alertDiv);
    
    // Show with animation
    setTimeout(() => {
        alertDiv.classList.add('show');
    }, 10);
    
    // Remove after delay
    setTimeout(() => {
        alertDiv.classList.remove('show');
        setTimeout(() => {
            alertDiv.remove();
        }, 300);
    }, 3000);
}

// Utility functions
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
}