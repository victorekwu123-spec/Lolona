// Admin Panel JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize admin panel
    initAdminPanel();
});

function initAdminPanel() {
    // Set up event listeners
    setupAdminEvents();
    
    // Check authentication
    checkAdminAuth();
    
    console.log('Admin panel initialized successfully!');
}

function setupAdminEvents() {
    // Sidebar toggle
    const sidebarToggle = document.querySelector('.sidebar-toggle');
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            document.querySelector('.admin-sidebar').classList.toggle('collapsed');
        });
    }
    
    // User dropdown
    const adminUser = document.querySelector('.admin-user');
    if (adminUser) {
        adminUser.addEventListener('click', function() {
            // Toggle user dropdown menu (would be implemented in a real app)
            console.log('User dropdown clicked');
        });
    }
    
    // Notification button
    const notificationBtn = document.querySelector('.notification-btn');
    if (notificationBtn) {
        notificationBtn.addEventListener('click', function() {
            // Toggle notifications panel (would be implemented in a real app)
            console.log('Notifications clicked');
        });
    }
    
    // Logout button
    const logoutBtn = document.querySelector('.logout');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            logout();
        });
    }
    
    // Admin search
    const adminSearch = document.querySelector('.admin-search input');
    if (adminSearch) {
        adminSearch.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                // Perform search (would be implemented in a real app)
                console.log('Searching for:', this.value);
            }
        });
    }
}

function checkAdminAuth() {
    // Check if user is logged in and is an admin
    const currentUser = JSON.parse(localStorage.getItem('recipeGoblinCurrentUser') || 'null');
    
    // Get all users to check if this user is an admin
    const allUsers = JSON.parse(localStorage.getItem('recipeGoblinUsers') || '[]');
    const userDetails = allUsers.find(user => currentUser && user.email === currentUser.email);
    
    if (!currentUser || !userDetails || userDetails.role !== 'admin') {
        // Not logged in or not an admin, redirect to login
        // In a real app, you would redirect to login page
        console.log('User is not authenticated as admin');
        
        // For demo purposes, we'll just show an alert
        // In a real app, you would redirect to login page
        // window.location.href = '../login.html';
    } else {
        // User is authenticated as admin
        console.log('User authenticated as admin:', currentUser.fullname);
        
        // Update admin user display
        updateAdminUserDisplay(currentUser);
    }
}

function updateAdminUserDisplay(user) {
    const adminUserInfo = document.querySelector('.admin-user-info');
    if (adminUserInfo) {
        const nameElement = adminUserInfo.querySelector('h4');
        if (nameElement) {
            nameElement.textContent = user.fullname;
        }
    }
}

function logout() {
    // Clear current user
    localStorage.removeItem('recipeGoblinCurrentUser');
    
    // Redirect to login page
    window.location.href = '../login.html';
}

// Utility functions for the admin panel

// Format date for display
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric'
    });
}

// Format time for display
function formatTime(dateString) {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit'
    });
}

// Format date and time for display
function formatDateTime(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit', 
        minute: '2-digit'
    });
}

// Format number with commas
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

// Truncate text with ellipsis
function truncateText(text, maxLength) {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
}

// Show notification
function showNotification(message, type = 'success') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `admin-notification ${type}`;
    notification.innerHTML = `
        <div class="notification-icon">
            <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
        </div>
        <div class="notification-content">
            <p>${message}</p>
        </div>
        <button class="notification-close">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    // Add to DOM
    document.body.appendChild(notification);
    
    // Add close button event
    notification.querySelector('.notification-close').addEventListener('click', function() {
        notification.classList.add('closing');
        setTimeout(() => {
            notification.remove();
        }, 300);
    });
    
    // Show notification with animation
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    // Auto hide after delay
    setTimeout(() => {
        notification.classList.add('closing');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 5000);
}