// Admin Dashboard JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize dashboard
    initAdminDashboard();
});

function initAdminDashboard() {
    // Load dashboard data
    loadDashboardData();
    
    // Initialize charts
    initUserActivityChart();
    initRecipeCategoriesChart();
    
    console.log('Admin dashboard initialized successfully!');
}

function loadDashboardData() {
    // Load users count
    const users = JSON.parse(localStorage.getItem('recipeGoblinUsers') || '[]');
    document.getElementById('total-users-count').textContent = users.length;
    
    // For demo purposes, we'll set some sample data for other stats
    // In a real app, this would come from the backend
    document.getElementById('total-recipes-count').textContent = '87';
    document.getElementById('total-views-count').textContent = '4,523';
    document.getElementById('total-comments-count').textContent = '256';
}

function initUserActivityChart() {
    const ctx = document.getElementById('userActivityChart');
    if (!ctx) return;
    
    // Sample data for the user activity chart
    const labels = ['Aug 1', 'Aug 5', 'Aug 10', 'Aug 15', 'Aug 20', 'Aug 25'];
    const registrationsData = [5, 8, 12, 9, 15, 20];
    const loginData = [12, 15, 20, 18, 25, 30];
    const recipeCreationData = [3, 5, 8, 6, 10, 12];
    
    // Create the chart
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'New Registrations',
                    data: registrationsData,
                    borderColor: '#4CAF50',
                    backgroundColor: 'rgba(76, 175, 80, 0.1)',
                    tension: 0.4,
                    borderWidth: 2,
                    pointBackgroundColor: '#4CAF50',
                    fill: true
                },
                {
                    label: 'User Logins',
                    data: loginData,
                    borderColor: '#2196F3',
                    backgroundColor: 'rgba(33, 150, 243, 0.1)',
                    tension: 0.4,
                    borderWidth: 2,
                    pointBackgroundColor: '#2196F3',
                    fill: true
                },
                {
                    label: 'Recipe Creation',
                    data: recipeCreationData,
                    borderColor: '#FF9800',
                    backgroundColor: 'rgba(255, 152, 0, 0.1)',
                    tension: 0.4,
                    borderWidth: 2,
                    pointBackgroundColor: '#FF9800',
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    align: 'end',
                    labels: {
                        boxWidth: 10,
                        usePointStyle: true
                    }
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        drawBorder: false
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
}

function initRecipeCategoriesChart() {
    const ctx = document.getElementById('recipeCategoriesChart');
    if (!ctx) return;
    
    // Sample data for the recipe categories chart
    const data = {
        labels: ['Breakfast', 'Lunch', 'Dinner', 'Dessert', 'Snack'],
        datasets: [{
            data: [15, 20, 30, 22, 13],
            backgroundColor: [
                '#4CAF50',
                '#2196F3',
                '#FF9800',
                '#E91E63',
                '#9C27B0'
            ],
            borderWidth: 0,
            borderRadius: 5
        }]
    };
    
    // Create the chart
    new Chart(ctx, {
        type: 'doughnut',
        data: data,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        boxWidth: 10,
                        usePointStyle: true,
                        padding: 20
                    }
                }
            },
            cutout: '70%'
        }
    });
}

// Add event listeners for dashboard elements
document.addEventListener('DOMContentLoaded', function() {
    // Export report button
    const exportReportBtn = document.querySelector('.admin-actions button:nth-child(2)');
    if (exportReportBtn) {
        exportReportBtn.addEventListener('click', function() {
            alert('Report export functionality would be implemented here.');
        });
    }
    
    // Date range selector
    const dateRangeBtn = document.querySelector('.admin-actions button:nth-child(1)');
    if (dateRangeBtn) {
        dateRangeBtn.addEventListener('click', function() {
            alert('Date range selector would be implemented here.');
        });
    }
    
    // Chart action buttons
    const chartActionBtns = document.querySelectorAll('.chart-actions .btn-icon');
    chartActionBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const chartCard = this.closest('.chart-card');
            const chartTitle = chartCard.querySelector('.chart-header h3').textContent;
            alert(`Options for ${chartTitle} chart would be shown here.`);
        });
    });
    
    // View all links
    const viewAllLinks = document.querySelectorAll('.view-all');
    viewAllLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const sectionTitle = this.closest('.section-header').querySelector('h3').textContent;
            alert(`View all ${sectionTitle} would be implemented here.`);
        });
    });
});