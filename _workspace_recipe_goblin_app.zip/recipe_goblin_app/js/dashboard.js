// Dashboard JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize dashboard components
    initDashboard();
});

function initDashboard() {
    // Initialize charts
    initActivityChart();
    initCategoriesChart();
    
    // Set up event listeners
    setupDashboardEvents();
    
    console.log('Dashboard initialized successfully!');
}

function setupDashboardEvents() {
    // Mobile menu toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu');
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', function() {
            const navMenu = document.querySelector('.nav-menu');
            navMenu.classList.toggle('show');
        });
    }
    
    // Sidebar navigation
    const sidebarLinks = document.querySelectorAll('.sidebar-nav a');
    sidebarLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            // For demo purposes, prevent default and just toggle active class
            e.preventDefault();
            
            // Remove active class from all links
            sidebarLinks.forEach(l => {
                l.parentElement.classList.remove('active');
            });
            
            // Add active class to clicked link
            this.parentElement.classList.add('active');
        });
    });
    
    // Table action buttons
    const actionButtons = document.querySelectorAll('.table-actions .btn-icon');
    actionButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Get action type from icon
            const isEdit = this.querySelector('.fa-edit');
            const isDelete = this.querySelector('.fa-trash');
            
            // Get recipe info
            const row = this.closest('tr');
            const recipeName = row.querySelector('.recipe-info h4').textContent;
            
            if (isEdit) {
                alert(`Editing recipe: ${recipeName}`);
            } else if (isDelete) {
                if (confirm(`Are you sure you want to delete "${recipeName}"?`)) {
                    // Simulate deletion with animation
                    row.style.opacity = '0';
                    setTimeout(() => {
                        row.style.display = 'none';
                    }, 300);
                }
            }
        });
    });
}

function initActivityChart() {
    const ctx = document.getElementById('activityChart');
    if (!ctx) return;
    
    // Sample data for the activity chart
    const labels = ['Aug 1', 'Aug 5', 'Aug 10', 'Aug 15', 'Aug 20', 'Aug 25'];
    const recipeData = [5, 8, 12, 9, 15, 20];
    const viewsData = [120, 250, 180, 310, 280, 420];
    
    // Create the chart
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Recipes Created',
                    data: recipeData,
                    borderColor: '#4CAF50',
                    backgroundColor: 'rgba(76, 175, 80, 0.1)',
                    tension: 0.4,
                    borderWidth: 2,
                    pointBackgroundColor: '#4CAF50',
                    fill: true
                },
                {
                    label: 'Recipe Views',
                    data: viewsData,
                    borderColor: '#FF9800',
                    backgroundColor: 'rgba(255, 152, 0, 0.1)',
                    tension: 0.4,
                    borderWidth: 2,
                    pointBackgroundColor: '#FF9800',
                    fill: true,
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    align: 'end',
                    labels: {
                        boxWidth: 10,
                        usePointStyle: true
                    }
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Recipes Created'
                    },
                    grid: {
                        drawBorder: false
                    }
                },
                y1: {
                    beginAtZero: true,
                    position: 'right',
                    title: {
                        display: true,
                        text: 'Recipe Views'
                    },
                    grid: {
                        display: false
                    }
                },
                x: {
                    grid: {
                        drawBorder: false
                    }
                }
            }
        }
    });
}

function initCategoriesChart() {
    const ctx = document.getElementById('categoriesChart');
    if (!ctx) return;
    
    // Sample data for the categories chart
    const data = {
        labels: ['Breakfast', 'Lunch', 'Dinner', 'Dessert', 'Snack'],
        datasets: [{
            data: [8, 7, 12, 5, 3],
            backgroundColor: [
                '#4CAF50',
                '#FF9800',
                '#2196F3',
                '#E91E63',
                '#9C27B0'
            ],
            borderWidth: 0,
            borderRadius: 5
        }]
    };
    
    // Create the chart
    new Chart(ctx, {
        type: 'doughnut',
        data: data,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        boxWidth: 10,
                        usePointStyle: true,
                        padding: 20
                    }
                }
            },
            cutout: '70%'
        }
    });
}

// Utility functions
function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}